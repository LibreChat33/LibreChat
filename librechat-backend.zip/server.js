const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const { v4: uuidv4 } = require('uuid');

const app = express();
const server = http.createServer(app);

const io = new Server(server, {
  cors: {
    origin: process.env.FRONTEND_URL || '*',
    methods: ['GET', 'POST'],
  },
});

app.use(cors());
app.use(express.json());

// ─── In-memory state (Redis-ready structure) ────────────────────────────────
const state = {
  users: new Map(),      // socketId → { id, username, color, room, typingIn }
  rooms: new Map(),      // roomId  → { id, name, icon, desc, messages[], users: Set }
  dmChannels: new Map(), // channelId → { users: [], messages[] }
  autodestruct: new Map(), // messageId → timeout
};

// ─── Seed rooms ─────────────────────────────────────────────────────────────
const ROOMS = [
  { id: 'general',  name: 'Chat Général', icon: '💬', desc: 'Discussions libres' },
  { id: 'gaming',   name: 'Gaming',       icon: '🎮', desc: 'Jeux vidéo & eSport' },
  { id: 'musique',  name: 'Musique',      icon: '🎵', desc: 'Découvertes & partages' },
  { id: 'detente',  name: 'Détente',      icon: '🌿', desc: 'Espace calme & bien-être' },
  { id: 'tech',     name: 'Tech & Code',  icon: '💻', desc: 'Dev, IA, Open Source' },
  { id: 'art',      name: 'Art & Créa',   icon: '🎨', desc: 'Dessin, photo, design' },
];

ROOMS.forEach(r => state.rooms.set(r.id, { ...r, messages: [], users: new Set() }));

// ─── Username generator ──────────────────────────────────────────────────────
const ADJS  = ['Loup','Renard','Tigre','Lynx','Corbeau','Faucon','Viper','Ombre','Neon','Pixel','Cyber','Ghost','Storm','Nova','Blitz','Zephyr','Flux','Aero','Kairo','Vox'];
const COLS  = ['Bleu','Violet','Noir','Rouge','Vert','Blanc','Gris','Doré','Argent','Crimson','Azur','Magenta','Indigo','Cobalt','Jade'];
const PALETTE = ['#7c5cfc','#a78bfa','#60a5fa','#f59e0b','#ef4444','#10b981','#ec4899','#06b6d4','#f97316','#14b8a6'];

function generateUsername() {
  const adj = ADJS[Math.floor(Math.random() * ADJS.length)];
  const col = COLS[Math.floor(Math.random() * COLS.length)];
  const num = Math.floor(Math.random() * 9000) + 1000;
  return `${adj}${col}#${num}`;
}

function pickColor(username) {
  let h = 0;
  for (let i = 0; i < username.length; i++) h = (h * 31 + username.charCodeAt(i)) % PALETTE.length;
  return PALETTE[h];
}

// ─── REST endpoints ──────────────────────────────────────────────────────────
app.get('/health', (_, res) => res.json({ status: 'ok', users: state.users.size }));

app.get('/rooms', (_, res) => {
  const rooms = ROOMS.map(r => {
    const room = state.rooms.get(r.id);
    return { ...r, online: room.users.size, lastMessages: room.messages.slice(-3) };
  });
  res.json(rooms);
});

app.get('/rooms/:roomId/messages', (req, res) => {
  const room = state.rooms.get(req.params.roomId);
  if (!room) return res.status(404).json({ error: 'Room not found' });
  res.json(room.messages.slice(-50));
});

// ─── Helper: broadcast room stats ───────────────────────────────────────────
function broadcastRoomStats(roomId) {
  const room = state.rooms.get(roomId);
  if (!room) return;
  io.to(roomId).emit('room:stats', { roomId, online: room.users.size });
  io.emit('rooms:update', { roomId, online: room.users.size });
}

// ─── Helper: schedule autodestruct ──────────────────────────────────────────
function scheduleDestruct(messageId, roomId, delayMs) {
  const t = setTimeout(() => {
    io.to(roomId).emit('message:destruct', { messageId });
    state.autodestruct.delete(messageId);
  }, delayMs);
  state.autodestruct.set(messageId, t);
}

// ─── Socket.io ──────────────────────────────────────────────────────────────
io.on('connection', (socket) => {
  console.log(`[+] Socket connected: ${socket.id}`);

  // ── 1. Join as anonymous user ─────────────────────────────────────────────
  socket.on('user:join', ({ username, color } = {}) => {
    const name  = username || generateUsername();
    const clr   = color   || pickColor(name);
    const user  = { id: socket.id, username: name, color: clr, room: null, typingIn: null };
    state.users.set(socket.id, user);

    socket.emit('user:joined', {
      id: socket.id,
      username: name,
      color: clr,
      rooms: ROOMS.map(r => ({ ...r, online: state.rooms.get(r.id).users.size })),
    });
    console.log(`  User joined: ${name}`);
  });

  // ── 2. Change username ────────────────────────────────────────────────────
  socket.on('user:rename', ({ username }) => {
    const user = state.users.get(socket.id);
    if (!user) return;
    const oldName = user.username;
    user.username = username || generateUsername();
    user.color    = pickColor(user.username);

    socket.emit('user:renamed', { username: user.username, color: user.color });

    if (user.room) {
      io.to(user.room).emit('room:userRenamed', {
        socketId: socket.id, oldName, newName: user.username, color: user.color,
      });
      broadcastRoomUsers(user.room);
    }
  });

  // ── 3. Join a room ────────────────────────────────────────────────────────
  socket.on('room:join', ({ roomId }) => {
    const user = state.users.get(socket.id);
    const room = state.rooms.get(roomId);
    if (!user || !room) return;

    // Leave previous room
    if (user.room && user.room !== roomId) {
      leaveRoom(socket, user, user.room);
    }

    socket.join(roomId);
    user.room = roomId;
    room.users.add(socket.id);

    socket.emit('room:joined', {
      roomId,
      messages: room.messages.slice(-50),
      users: getRoomUsers(roomId),
      online: room.users.size,
    });

    io.to(roomId).emit('room:userJoined', {
      socketId: socket.id,
      username: user.username,
      color: user.color,
      online: room.users.size,
    });

    broadcastRoomStats(roomId);
    broadcastRoomUsers(roomId);
    console.log(`  ${user.username} joined #${roomId}`);
  });

  // ── 4. Send message ───────────────────────────────────────────────────────
  socket.on('message:send', ({ roomId, text, autodestruct }) => {
    const user = state.users.get(socket.id);
    const room = state.rooms.get(roomId);
    if (!user || !room || !text?.trim()) return;

    const msg = {
      id: uuidv4(),
      roomId,
      userId: socket.id,
      username: user.username,
      color: user.color,
      text: text.trim().slice(0, 2000),
      timestamp: Date.now(),
      autodestruct: autodestruct || null, // ms or null
    };

    // Only persist non-autodestruct messages
    if (!autodestruct) {
      room.messages.push(msg);
      if (room.messages.length > 200) room.messages.shift();
    }

    io.to(roomId).emit('message:new', msg);

    if (autodestruct) {
      scheduleDestruct(msg.id, roomId, autodestruct);
    }
  });

  // ── 5. Typing indicator ───────────────────────────────────────────────────
  socket.on('typing:start', ({ roomId }) => {
    const user = state.users.get(socket.id);
    if (!user) return;
    user.typingIn = roomId;
    socket.to(roomId).emit('typing:update', {
      socketId: socket.id, username: user.username, color: user.color, typing: true,
    });
  });

  socket.on('typing:stop', ({ roomId }) => {
    const user = state.users.get(socket.id);
    if (!user) return;
    user.typingIn = null;
    socket.to(roomId).emit('typing:update', {
      socketId: socket.id, username: user.username, typing: false,
    });
  });

  // ── 6. Private messages (DM) ──────────────────────────────────────────────
  socket.on('dm:send', ({ toSocketId, text }) => {
    const from = state.users.get(socket.id);
    const to   = state.users.get(toSocketId);
    if (!from || !to || !text?.trim()) return;

    const channelId = [socket.id, toSocketId].sort().join(':');
    if (!state.dmChannels.has(channelId)) {
      state.dmChannels.set(channelId, { users: [socket.id, toSocketId], messages: [] });
    }

    const msg = {
      id: uuidv4(),
      channelId,
      from: socket.id,
      fromUsername: from.username,
      fromColor: from.color,
      text: text.trim().slice(0, 2000),
      timestamp: Date.now(),
    };

    state.dmChannels.get(channelId).messages.push(msg);
    socket.emit('dm:message', msg);
    io.to(toSocketId).emit('dm:message', msg);
  });

  // ── 7. Disconnect ─────────────────────────────────────────────────────────
  socket.on('disconnect', () => {
    const user = state.users.get(socket.id);
    if (!user) return;

    if (user.room) leaveRoom(socket, user, user.room);
    if (user.typingIn) {
      socket.to(user.typingIn).emit('typing:update', {
        socketId: socket.id, typing: false,
      });
    }

    state.users.delete(socket.id);
    console.log(`[-] Disconnected: ${user.username}`);
  });

  // ── Helpers ───────────────────────────────────────────────────────────────
  function leaveRoom(sock, user, roomId) {
    const room = state.rooms.get(roomId);
    if (!room) return;
    sock.leave(roomId);
    room.users.delete(sock.id);
    user.room = null;
    io.to(roomId).emit('room:userLeft', {
      socketId: sock.id, username: user.username, online: room.users.size,
    });
    broadcastRoomStats(roomId);
    broadcastRoomUsers(roomId);
  }

  function getRoomUsers(roomId) {
    const room = state.rooms.get(roomId);
    if (!room) return [];
    return [...room.users].map(id => {
      const u = state.users.get(id);
      return u ? { id, username: u.username, color: u.color } : null;
    }).filter(Boolean);
  }

  function broadcastRoomUsers(roomId) {
    io.to(roomId).emit('room:users', { roomId, users: getRoomUsers(roomId) });
  }
});

// ─── Start ───────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
server.listen(PORT, () => {
  console.log(`\n🚀 LibreChat backend running on port ${PORT}`);
  console.log(`   Rooms: ${ROOMS.map(r => r.id).join(', ')}\n`);
});
