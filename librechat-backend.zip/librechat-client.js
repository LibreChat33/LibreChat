// librechat-client.js
// Colle ce fichier dans ton projet React/frontend
// npm install socket.io-client

import { io } from 'socket.io-client';

const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:3001';

// ─── Singleton socket ─────────────────────────────────────────────────────────
let socket = null;

export function getSocket() {
  if (!socket) {
    socket = io(BACKEND_URL, {
      transports: ['websocket'],
      autoConnect: false,
    });
  }
  return socket;
}

// ─── High-level API ───────────────────────────────────────────────────────────

/** Connect and register as anonymous user */
export function connect({ username, color } = {}) {
  const s = getSocket();
  s.connect();
  s.once('connect', () => {
    s.emit('user:join', { username, color });
  });
  return s;
}

/** Join a chat room */
export function joinRoom(roomId) {
  getSocket().emit('room:join', { roomId });
}

/** Send a message to a room */
export function sendMessage({ roomId, text, autodestruct = null }) {
  getSocket().emit('message:send', { roomId, text, autodestruct });
}

/** Send a DM */
export function sendDM({ toSocketId, text }) {
  getSocket().emit('dm:send', { toSocketId, text });
}

/** Typing indicators */
export function startTyping(roomId) {
  getSocket().emit('typing:start', { roomId });
}
export function stopTyping(roomId) {
  getSocket().emit('typing:stop', { roomId });
}

/** Change username */
export function rename(username) {
  getSocket().emit('user:rename', { username });
}

/** Disconnect */
export function disconnect() {
  getSocket().disconnect();
}

// ─── Autodestruct presets ─────────────────────────────────────────────────────
export const AUTODESTRUCT = {
  OFF:    null,
  S30:    30_000,
  MIN5:   5 * 60_000,
  HOUR1:  60 * 60_000,
};

// ─── React hook (optionnel) ───────────────────────────────────────────────────
// import { useEffect, useState } from 'react';
//
// export function useLibreChat({ username } = {}) {
//   const [me, setMe]           = useState(null);
//   const [messages, setMsgs]   = useState([]);
//   const [users, setUsers]     = useState([]);
//   const [typing, setTyping]   = useState([]);
//
//   useEffect(() => {
//     const s = connect({ username });
//
//     s.on('user:joined',   (data) => setMe(data));
//     s.on('room:joined',   (data) => { setMsgs(data.messages); setUsers(data.users); });
//     s.on('message:new',   (msg)  => setMsgs(prev => [...prev, msg]));
//     s.on('message:destruct', ({ messageId }) =>
//       setMsgs(prev => prev.filter(m => m.id !== messageId)));
//     s.on('room:users',    (data) => setUsers(data.users));
//     s.on('typing:update', ({ socketId, username, color, typing: t }) =>
//       setTyping(prev => t
//         ? [...prev.filter(u => u.socketId !== socketId), { socketId, username, color }]
//         : prev.filter(u => u.socketId !== socketId)
//       ));
//
//     return () => s.disconnect();
//   }, []);
//
//   return { me, messages, users, typing, joinRoom, sendMessage, sendDM, rename };
// }
