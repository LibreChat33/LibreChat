# LibreChat — Backend

Backend temps réel pour LibreChat. Node.js + Express + Socket.io.

## Stack
- **Express** — API REST légère
- **Socket.io** — WebSocket bidirectionnel
- **UUID** — IDs uniques pour chaque message
- **In-memory** — Aucune base de données, aucune persistence

## Installation locale

```bash
npm install
npm run dev        # développement avec hot-reload
npm start          # production
```

Serveur disponible sur `http://localhost:3001`

## Variables d'environnement

| Variable | Default | Description |
|----------|---------|-------------|
| `PORT` | `3001` | Port d'écoute |
| `FRONTEND_URL` | `*` | URL du frontend (CORS) |

Créer un fichier `.env` :
```
PORT=3001
FRONTEND_URL=https://ton-frontend.vercel.app
```

## API Socket.io — Événements

### Client → Serveur

| Événement | Payload | Description |
|-----------|---------|-------------|
| `user:join` | `{ username?, color? }` | Connexion anonyme |
| `user:rename` | `{ username }` | Changer de pseudo |
| `room:join` | `{ roomId }` | Rejoindre un salon |
| `message:send` | `{ roomId, text, autodestruct? }` | Envoyer un message |
| `typing:start` | `{ roomId }` | Début de frappe |
| `typing:stop` | `{ roomId }` | Fin de frappe |
| `dm:send` | `{ toSocketId, text }` | Message privé |

### Serveur → Client

| Événement | Payload | Description |
|-----------|---------|-------------|
| `user:joined` | `{ id, username, color, rooms[] }` | Confirmation connexion |
| `user:renamed` | `{ username, color }` | Pseudo changé |
| `room:joined` | `{ roomId, messages[], users[], online }` | Entrée dans un salon |
| `message:new` | `{ id, username, color, text, timestamp, autodestruct? }` | Nouveau message |
| `message:destruct` | `{ messageId }` | Message auto-détruit |
| `room:users` | `{ roomId, users[] }` | Liste utilisateurs |
| `room:stats` | `{ roomId, online }` | Compte en ligne |
| `typing:update` | `{ socketId, username, color, typing }` | Indicateur frappe |
| `dm:message` | `{ id, from, fromUsername, text, timestamp }` | Message privé reçu |

### Autodestruct presets
```js
null          // pas d'autodestruct
30_000        // 30 secondes
5 * 60_000    // 5 minutes
60 * 60_000   // 1 heure
```

## Déploiement sur Render.com

1. Push ce dossier sur GitHub
2. Nouveau service Web sur render.com
3. Build command : `npm install`
4. Start command : `npm start`
5. Ajouter variable d'env `FRONTEND_URL=https://ton-app.vercel.app`

## Structure mémoire

```
state.users      Map<socketId, User>
state.rooms      Map<roomId, { messages[], users: Set<socketId> }>
state.dmChannels Map<channelId, { users[], messages[] }>
```

Tout disparaît au redémarrage du serveur — c'est voulu. 🔒
